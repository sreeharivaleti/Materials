package collectionsref;

//File : State.java
public class State {
	private String stName;
	private String stCapital;
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public String getStCapital() {
		return stCapital;
	}
	public void setStCapital(String stCapital) {
		this.stCapital = stCapital;
	}
	
	

}
