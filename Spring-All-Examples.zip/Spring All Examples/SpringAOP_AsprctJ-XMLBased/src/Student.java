
public interface Student {

	void addStudent();

	String studentReturnValue();

	void studentThrowException() throws Exception;

	void studentAround(String name);
}